(function() {
  $(function() {
    return $("#nickname").typed({
      strings: ["JM", "Migi", "Juan Miguel", "Ige"],
      loop: true,
      typeSpeed: 269
    });
  });

}).call(this);
